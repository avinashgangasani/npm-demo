/*Versioning
format: Major.Minor.Patch
^ equivalent to Major.x
~ equivalent to Major.Minor.x*/
const _ = require('underscore');

console.log(_.contains([1, 2, 3, 4], 4));